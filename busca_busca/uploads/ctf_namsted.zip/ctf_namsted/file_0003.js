// Archivo de prueba #3
function prueba3() {
    // Este archivo forma parte del reto CTF.
    return "VCOAAJcmhX4m3aMYFADEng5T";
}
