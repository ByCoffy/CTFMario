// Archivo de prueba #10
function prueba10() {
    // Este archivo forma parte del reto CTF.
    return "lESxSaQpdFBiotuIWgAhnCMt";
}
