// Archivo de prueba #125
function prueba125() {
    // Este archivo forma parte del reto CTF.
    return "3cI9h2QQfdXHzngpra3FYTny";
}
