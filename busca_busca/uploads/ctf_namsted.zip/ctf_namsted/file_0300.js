// Archivo de prueba #300
function prueba300() {
    // Este archivo forma parte del reto CTF.
    return "4zu0rnArWCYQUiCPc7Lu5DNN";
}
