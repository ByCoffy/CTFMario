// Archivo de prueba #320
function prueba320() {
    // Este archivo forma parte del reto CTF.
    return "OOwYYZ0FxN5fPi4CTiD9tQNS";
}
