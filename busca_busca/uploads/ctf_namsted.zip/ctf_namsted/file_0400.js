// Archivo de prueba #400
function prueba400() {
    // Este archivo forma parte del reto CTF.
    return "YAZKqEPlIgjsS4uMJXgSQ6rO";
}
