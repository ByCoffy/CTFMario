// Archivo de prueba #500
function prueba500() {
    // Este archivo forma parte del reto CTF.
    return "Z0EAMYeFKjNBXPpSc2qzxFeu";
}
