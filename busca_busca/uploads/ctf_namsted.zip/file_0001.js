// Archivo de prueba #1
function prueba1() {
    // Este archivo forma parte del reto CTF.
    return "ScYM3cZXL6ccvCF5VAnDGGLC";
}
