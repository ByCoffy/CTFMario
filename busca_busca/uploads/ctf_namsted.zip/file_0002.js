// Archivo de prueba #2
function prueba2() {
    // Este archivo forma parte del reto CTF.
    return "YBRWKL0SYBddcd07y20zluMm";
}
