// Archivo de prueba #5
function prueba5() {
    // Este archivo forma parte del reto CTF.
    return "heKLGlunHpYdvDhgyTWCkdJp";
}
