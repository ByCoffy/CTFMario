// Archivo de prueba #8
function prueba8() {
    // Este archivo forma parte del reto CTF.
    return "vRo0we6DYjMSFQh7q4G8HoBc";
}
