// Archivo de prueba #123
function prueba123() {
    // Este archivo forma parte del reto CTF.
    return "tPbZrKtYCsx5FpOcee8sVNPG";
}
