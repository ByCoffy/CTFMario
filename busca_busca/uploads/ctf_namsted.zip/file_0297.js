// Archivo de prueba #297
function prueba297() {
    // Este archivo forma parte del reto CTF.
    return "NRUrYv0CKRRcsdbsadV3y1yb";
}
