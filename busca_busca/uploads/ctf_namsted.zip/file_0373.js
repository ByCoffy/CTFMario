// Archivo de prueba #373
function prueba373() {
    // Este archivo forma parte del reto CTF.
    return "Azt2sRjQy71MhCVCVQJolIWv";
}
